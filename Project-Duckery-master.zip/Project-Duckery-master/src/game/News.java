package game;

public class News {
}
