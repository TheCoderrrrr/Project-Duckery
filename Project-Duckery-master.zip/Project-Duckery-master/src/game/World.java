package game;

public class World {
}
