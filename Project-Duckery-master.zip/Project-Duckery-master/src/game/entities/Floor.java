package game.entities;

public class Floor {
}
