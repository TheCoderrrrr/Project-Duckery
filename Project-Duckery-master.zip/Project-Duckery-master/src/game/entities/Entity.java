package game.entities;

public abstract class Entity {
}
