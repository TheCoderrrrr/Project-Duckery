package game.entities;

public class Duck {
}
