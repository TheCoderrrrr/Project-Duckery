package game.entities;

public class Machine {
}
