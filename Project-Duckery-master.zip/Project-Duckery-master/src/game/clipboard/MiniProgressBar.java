package game.clipboard;

public class MiniProgressBar {
}
