package game.clipboard;

public abstract class ProgressBar {
}
