package game.clipboard.items;

public class Item {
}
