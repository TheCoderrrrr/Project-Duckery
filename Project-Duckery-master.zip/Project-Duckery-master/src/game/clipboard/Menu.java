package game.clipboard;

public class Menu {
}
