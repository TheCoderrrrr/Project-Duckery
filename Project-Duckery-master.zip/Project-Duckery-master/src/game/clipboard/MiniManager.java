package game.clipboard;

public class MiniManager {
}
