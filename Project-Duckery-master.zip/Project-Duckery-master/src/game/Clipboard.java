package game;

public class Clipboard {
}
