package open;

public class IntroAnimation {
}
