package open;

public class TitleScreen {
}
